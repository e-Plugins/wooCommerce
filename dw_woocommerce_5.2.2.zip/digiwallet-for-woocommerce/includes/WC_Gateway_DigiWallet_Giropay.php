<?php
/*DigiWallet Giropay Payment Gateway Class */
class WC_Gateway_DigiWallet_Giropay extends WC_Gateway_DigiWallet_Eps
{
    protected $payMethodId = "GIP";
    protected $payMethodName = "GiroPay";
    public $enabled = true;
} // End Class
