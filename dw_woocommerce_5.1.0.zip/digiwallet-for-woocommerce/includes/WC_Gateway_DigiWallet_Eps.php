<?php
use Digiwallet\Packages\Transaction\Client\Client;
use Digiwallet\Packages\Transaction\Client\Request\CreateTransaction;
use Digiwallet\Packages\Transaction\Client\Request\CheckTransaction;

/* DigiWallet EPS Payment Gateway Class */
class WC_Gateway_DigiWallet_Eps extends WC_Gateway_DigiWallet
{
    const DIGIWALLET_API = "https://api.digiwallet.nl/";
    
    const APP_ID = "dw_woocommerce3.x_5.1.0";
    
    protected $payMethodId = "EPS";

    protected $payMethodName = "EPS";

    public $enabled = true;

    /**
     * return method description
     *
     * {@inheritdoc}
     * @see WC_Gateway_DigiWallet::getDigiWalletMethodOption()
     * @return string
     */
    protected function getDigiWalletMethodOption()
    {
        return 'EPS';
    }

    /**
     * Submit payment and handle response
     *
     * {@inheritdoc}
     *
     * @see WC_Payment_Gateway::process_payment()
     */
    public function process_payment($order_id, $retry = true)
    {
        global $wpdb;

        $DigiWalletTable = $this->getDigiWalletTableName();

        $order = new WC_Order($order_id);
        $orderID = $order->get_id();
        $amount = $order->get_total();
        $digiwalletApi = new Client(self::DIGIWALLET_API);
        
        $formParams = [
            'outletId' => $this->rtlo,
            'currencyCode' => get_woocommerce_currency(),
            'consumerEmail' => $this->getConsumerEmail($order),
            'description' => ('Order ' . $order->get_order_number()),
            'returnUrl' => add_query_arg(array(
                'wc-api' => 'WC_Gateway_DigiWallet' . $this->payMethodId . 'Return',
                'od' => $orderID
            ), home_url('/')),
            'reportUrl' => add_query_arg(array(
                'wc-api' => 'WC_Gateway_DigiWallet' . $this->payMethodId . 'Report',
                'od' => $orderID
            ), home_url('/')),
            'consumerIp' => $this->getCustomerIP(),
            'suggestedLanguage' => 'NLD',
            'amountChangeable' => false,
            'inputAmount' => $amount * 100,
            'paymentMethods' => [
                $this->payMethodId
            ],
            'app_id' => self::APP_ID
        ];
        
        $request = new CreateTransaction($digiwalletApi, $formParams);
        $request->withBearer($this->token);
        /** @var \Digiwallet\Packages\Transaction\Client\Response\CreateTransaction $apiResult */
        $apiResult = $request->send();
        
        if ($apiResult->status() == 0) {
            $insert = $wpdb->insert($DigiWalletTable, array(
                'cart_id' => esc_sql($order->get_order_number()),
                'site_id' => get_current_blog_id(),
                'order_id' => esc_sql($order->get_id()),
                'rtlo' => esc_sql($this->rtlo),
                'paymethod' => esc_sql($this->payMethodId),
                'transaction_id' => esc_sql($apiResult->transactionId()),
                'more' => esc_sql(json_encode($apiResult->response()))
            ), array(
                '%s',
                '%d',
                '%d',
                '%s',
                '%s',
                '%s',
                '%s'
            ));
            if (! $insert) {
                $message = "Payment could not be started: can not insert into digiwallet table";
                wc_add_notice($message, $notice_type = 'error');
                $order->add_order_note($message);

                return false;
            }
            
            return $this->redirectAfterStart($apiResult->launchUrl(), $order);
        } else {
            $message = $apiResult->message();
            wc_add_notice($message, $notice_type = 'error');
            $order->add_order_note("Payment could not be started: {$message}");

            return false;
        }
    }
    
    /**
     * Update order (if report not working) && show payment result.
     *
     * @return mixed
     */
    public function check_digiwallet_return()
    {
        $orderId = ! empty($_REQUEST['od']) ? wc_clean($_REQUEST['od']) : null;
        $trxid = wc_clean($_REQUEST['transactionID']);
        
        if ($orderId && $trxid) {
            $order = new WC_Order($orderId);
            if ($order->post == null) {
                echo 'Order ' . esc_html($orderId) . ' not found... ';
                die();
            }
            $extOrder = $this->getExtOrder($orderId, $trxid);
            
            if ($extOrder == null) { // Oeps something wrong... Some extra debug information for Digiwallet
                echo 'Transaction not found...';
                die();
            }
            if (!in_array($order->get_status(), array_keys($this->list_success_status))) {//check order in return if status != success
                $order = $this->checkOrder($order, $extOrder);
            }
            $this->redirectAfterCheck($order, $trxid);
        }
        echo 'Order ' . esc_html($orderId) . ' not found... ';
        die();
    }
    
    /**
     * Process report URL
     * Update order when status = pending.
     * @return none
     */
    public function check_digiwallet_report()
    {
        $orderId = ! empty($_REQUEST['od']) ? wc_clean($_REQUEST['od']) : null;
        $trxid = wc_clean($_REQUEST['transactionID']);
        
        //         if ( substr($_SERVER['REMOTE_ADDR'],0,10) == "89.184.168" ||
        //             substr($_SERVER['REMOTE_ADDR'],0,9) == "78.152.58" ) {
        if ($orderId && $trxid) {
            $order = new WC_Order($orderId);
            $extOrder = $this->getExtOrder($orderId, $trxid);
            if (!$order || !$extOrder) {
                die("order is not found");
            }
            //Ignore updating Woo Order if Order Status is Paid (completed, processing)
            if (in_array($order->get_status(), array_keys($this->list_success_status))) {
                echo "order " . esc_html($orderId) . " had been done";
                die;
            }
            $log_msg = 'Prev status= ' . esc_html($order->get_status()) . PHP_EOL;
            $this->checkOrder($order, $extOrder);
            $log_msg .= 'current status= ' . esc_html($order->get_status()) . PHP_EOL;
            $log_msg .= 'order number= ' . esc_html($orderId) . PHP_EOL;
            $log_msg .= 'Version=wc 1.2.1';
            
            if(WP_DEBUG) {
                error_log($log_msg);
            }
            
            die($log_msg);
        }
        die("orderId || trxid is empty");
        //         } else {
        //             die("IP address not correct... This call is not from Digiwallet");
        //         }
    }
    
    public function checkOrder(WC_Order $order, $extOrder)
    {
        $digiwalletApi = new Client(self::DIGIWALLET_API);
        $request = new CheckTransaction($digiwalletApi);
        $request->withBearer($this->token);
        $request->withOutlet($this->rtlo);
        $request->withTransactionId($extOrder->transaction_id);
        /** @var \Digiwallet\Packages\Transaction\Client\Response\CheckTransaction $apiResult */
        $apiResult = $request->send();

        if ($apiResult->getStatus() == 0 && $apiResult->getTransactionStatus() == 'Completed') {
            $order->update_status($this->orderStatus, "Method {$order->get_payment_method_title()}(Transaction ID $extOrder->transaction_id): ");
            $order->set_transaction_id($extOrder->transaction_id);
            $order->save();
            $this->updateDigiWalletTable($order, array('message' => null));
            do_action( 'woocommerce_payment_complete', $order->get_id());
        } else {
            $this->updateDigiWalletTable($order, array('message' => esc_sql($apiResult->getMessage())));
            $order->update_status(self::WOO_ORDER_STATUS_FAILED, "Method {$order->get_payment_method_title()}(Transaction ID $extOrder->transaction_id): ");
        }
        
        return $order;
    }
    
    /**
     * Process refund.
     *
     * If the gateway declares 'refunds' support, this will allow it to refund.
     * a passed in amount.
     *
     * @param int $order_id
     * @param float $amount
     * @param string $reason
     * @return boolean True or false based on success, or a WP_Error object.
     */
    public function process_refund($order_id, $amount = null, $reason = '')
    {
        return false;
    }
} // End Class
