<?php
/*DigiWallet Paypal Payment Gateway Class */
class WC_Gateway_DigiWallet_Paypal extends WC_Gateway_DigiWallet
{
    protected $payMethodId = "PYP";
    protected $payMethodName = "Paypal";
    protected $maxAmount = 10000;
    protected $minAmount = 0.84;
    public $enabled = false;
} // End Class
